package com.tnsif.shoppingmall.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tnsif.shoppingmall.entity.User;
import com.tnsif.shoppingmall.repository.UserRepository;

@RestController
@RequestMapping("/user")
public class UserController {

	@Autowired
	private UserRepository userRepo;

	@GetMapping("/{id}")
	public User getUserById(@PathVariable Long id) {
		return userRepo.findById(id).get();
	}

	@GetMapping
	public List<User> getAllUsers() {
		return userRepo.findAll();
	}

	@PostMapping
	public User createUser(@RequestBody User User) {
		return userRepo.save(User);
	}

	@PutMapping("/{id}")
	public void updateUser(@PathVariable Long id, @RequestBody User user) {

		user.setId(id);
		userRepo.save(user);

	}

	@DeleteMapping("/{id}")
	public void deleteUserById(@PathVariable Long id) {
		userRepo.deleteById(id);
	}
}
